"""Confere os arquivos do DT05: lê cada um como um importador leria e lista o que difere do DT01."""
import csv
import io
import sys
import unicodedata
from pathlib import Path

from openpyxl import load_workbook

csv.field_size_limit(10**9)
PASTA = Path(sys.argv[1] if len(sys.argv) > 1 else "/home/claude/dt01/saida_dt05/DT05")
BASE = Path("/home/claude/dt01/saida/DT01_ficha_v1.csv")
COLUNAS = ["Rotina", "Dia", "Ordem", "Grupo", "Exercício", "Séries", "Meta", "Carga", "Técnica",
           "Descanso", "Unilateral", "Observações"]


def chave(t):
    t = unicodedata.normalize("NFKD", str(t)).encode("ascii", "ignore").decode()
    return t.strip().lower()


MAPA = {chave(c): c for c in COLUNAS}


def ler_csv(p):
    bruto = p.read_bytes()
    for cod in ("utf-8-sig", "cp1252"):
        try:
            texto = bruto.decode(cod)
            break
        except UnicodeDecodeError:
            continue
    cab = texto.splitlines()[0]
    sep = max([";", ",", "\t"], key=cab.count)
    linhas = list(csv.reader(io.StringIO(texto), delimiter=sep))
    return cod, sep, linhas


def ler_xlsx(p):
    wb = load_workbook(p, data_only=True)
    ws = wb["Ficha"] if "Ficha" in wb.sheetnames else wb.worksheets[0]
    versao = None
    if "Instruções" in wb.sheetnames:
        for row in wb["Instruções"].iter_rows(values_only=True):
            if row and row[0] == "Versão do formato":
                versao = row[1]
    linhas = [["" if v is None else str(v) for v in row] for row in ws.iter_rows(values_only=True)]
    return wb.sheetnames, versao, linhas


def como_dicts(linhas):
    cab = [MAPA.get(chave(c), f"?{c}") for c in linhas[0]]
    return cab, [dict(zip(cab, l)) for l in linhas[1:]]


base = [dict(l) for l in csv.DictReader(open(BASE, encoding="utf-8-sig"), delimiter=";")]
for p in sorted(PASTA.glob("DT05-*")):
    info = f"{p.stat().st_size:>9} B"
    if p.suffix == ".xlsx":
        abas, versao, linhas = ler_xlsx(p)
        info += f" | abas {abas} versão {versao}"
        if "Ficha" not in abas:
            print(f"{p.name}\n   {info} | layout fora do modelo: {len(linhas)} linhas na planilha")
            for l in linhas[:5]:
                print("     ", [x for x in l if x])
            continue
    else:
        cod, sep, linhas = ler_csv(p)
        bom = p.read_bytes()[:3] == b"\xef\xbb\xbf"
        info += f" | {cod}{' com BOM' if bom else (' sem BOM' if cod == 'utf-8-sig' else '')} | separador {sep!r}"
    cab, rows = como_dicts(linhas)
    extras = [c for c in cab if c.startswith("?")]
    faltam = [c for c in COLUNAS if c not in cab]
    info += f" | {len(rows)} linhas de dados"
    if extras: info += f" | colunas fora do formato {extras}"
    if faltam: info += f" | faltam {faltam}"
    print(p.name + "\n   " + info)
    if len(rows) != 30:
        continue
    for i, (b, r) in enumerate(zip(base, rows), start=2):
        for c in COLUNAS:
            if c in r and r[c] != b[c]:
                v = r[c] if len(r[c]) <= 40 else f"{r[c][:20]}... ({len(r[c])} caracteres)"
                print(f"     linha {i} {c}: {b[c]!r} -> {v!r}")
